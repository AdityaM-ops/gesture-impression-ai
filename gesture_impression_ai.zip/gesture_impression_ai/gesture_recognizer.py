import cv2
import mediapipe as mp

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

def get_finger_states(landmarks):
    """
    Determine if each finger is up or down.
    Returns a list: [thumb, index, middle, ring, pinky]
    """
    wrist_y = landmarks[0].y

    thumb_up = landmarks[4].x < landmarks[3].x  # For right hand
    index_up = landmarks[8].y < landmarks[6].y
    middle_up = landmarks[12].y < landmarks[10].y
    ring_up = landmarks[16].y < landmarks[14].y
    pinky_up = landmarks[20].y < landmarks[18].y

    return [thumb_up, index_up, middle_up, ring_up, pinky_up]

def classify_hand_gesture(landmarks):
    finger_states = get_finger_states(landmarks)

    # Unpack
    thumb, index, middle, ring, pinky = finger_states

    # Classification logic
    if thumb and not index and not middle and not ring and not pinky:
        return "Thumbs Up"
    elif index and middle and not ring and not pinky:
        return "Peace Sign"
    elif all([index, middle, ring, pinky, thumb]):
        return "Open Palm"
    elif not any([index, middle, ring, pinky, thumb]):
        return "Fist"
    else:
        return "Unknown Gesture"

def detect_gesture_from_frame(frame):
    with mp_hands.Hands(static_image_mode=False,
                        max_num_hands=1,
                        min_detection_confidence=0.7,
                        min_tracking_confidence=0.7) as hands:

        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(image_rgb)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                gesture = classify_hand_gesture(hand_landmarks.landmark)
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                return gesture, frame

        return "No Hand", frame

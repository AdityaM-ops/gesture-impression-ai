# llm_sentiment.py

def interpret_gesture_with_llm(gesture):
    import ollama

    if gesture in ["No Hand", "Hand Detected"]:
        return "No clear gesture to interpret."

    prompt = f"In one line, what does the gesture '{gesture}' usually mean in human communication?"

    try:
        response = ollama.chat(
            model='llama3',
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        return response['message']['content'].strip()
    except Exception as e:
        return f"❌ Ollama Error: {str(e)}"

Gesture Impression AI
=======================

This project uses MediaPipe and OpenCV to detect hand gestures via webcam
and interprets them using a local LLM (LLaMA3 via Ollama).

------------------------
Setup Instructions:
------------------------

1. Install dependencies:
   pip install -r requirements.txt

2. Start the Ollama server (if not already running):
   ollama serve

3. Pull the LLaMA3 model if needed:
   ollama pull llama3

4. Activate your virtual environment:
   On Windows:
     .\venv\Scripts\activate

5. Run the Streamlit app:
   streamlit run app.py

------------------------
Files Included:
------------------------

- app.py                 → Main Streamlit interface
- gesture_recognizer.py → Hand gesture detection using MediaPipe
- llm_sentiment.py      → LLM interpretation using Ollama
- requirements.txt      → List of required Python packages
- README.txt            → This file

------------------------
Requirements:
------------------------

- Python 3.8+
- Ollama (for LLaMA3)
- OpenCV
- MediaPipe
- Streamlit

------------------------
Author:
------------------------

Aditya Mukherjee
